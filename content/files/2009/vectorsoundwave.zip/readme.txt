SM3603 Interactivity I
Final project
Li Wing Ho Andy 51139476
Build date: 20090520

Complied by Flex Builder, with Flex sdk 3.3.

Libraries used:
popforge	http://code.google.com/p/popforge/
CasaLib		http://casalib.org/
Degrafa		http://degrafa.org/

InteractivePoint.mxml is from http://algorithmist.wordpress.com/2009/01/19/degrafa-cubic-bezier-y-at-x/

Online report is available at http://blog.onthewings.net/2009/05/20/vector-sound-wave-morphing/